﻿using BookingManager.Domain;
using BookingManager.Exceptions;
using System;
using System.Collections.Generic;

namespace BookingManager.Repository
{
    class RoomRepository
    {
        public static readonly RoomRepository Instance = new();
        public readonly IReadOnlyDictionary<int, Room> Rooms = new Dictionary<int, Room>
        {
            { 101, new Room{RoomNumber = 101} },
            { 102,new Room{ RoomNumber = 102} },
            {201, new Room{RoomNumber = 201} },
            {203, new Room{ RoomNumber = 203} }
        };
        private RoomRepository()
        {

        }

        public bool TryGetRoom(int roomNumber, DateTime date, out Room room)
        {
            if (!Rooms.ContainsKey(roomNumber)) throw new RoomNotExistsException(roomNumber);
            room = Rooms[roomNumber];
            return !(room.Bookings?.ContainsKey(date) ?? false);
        }
    }
}
