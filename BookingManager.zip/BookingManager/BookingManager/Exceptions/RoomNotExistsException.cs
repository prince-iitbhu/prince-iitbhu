﻿using System;

namespace BookingManager.Exceptions
{
    [Serializable]
    internal class RoomNotExistsException : RoomNotAvailableException
    {
        public RoomNotExistsException(int roomNumber) : base($"room {roomNumber} does not exist")
        {
        }
    }
}