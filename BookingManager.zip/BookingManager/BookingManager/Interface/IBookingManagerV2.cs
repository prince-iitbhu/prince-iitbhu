﻿using System;
using System.Collections.Generic;

namespace BookingManager.Interface
{
    interface IBookingManagerV2 : IBookingManager
    {
        /**
         * Return a list of all the available room numbers for the given date 
         */
        IEnumerable<int> getAvailableRooms(DateTime date);

    }
}
