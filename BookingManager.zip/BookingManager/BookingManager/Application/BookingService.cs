﻿using BookingManager.Domain;
using BookingManager.Exceptions;
using BookingManager.Interface;
using BookingManager.Repository;
using System;

namespace BookingManager.Application
{
    class BookingService : IBookingManager
    {
        static readonly object lockObject = new();
        readonly RoomRepository _roomRepository = RoomRepository.Instance;
        public void AddBooking(string guest, int roomNumber, DateTime date)
        {
            if (!_roomRepository.TryGetRoom(roomNumber, date, out var room)) throw new RoomNotAvailableException(roomNumber);
            lock (lockObject)
            {
                if (room.Bookings.ContainsKey(date)) throw new RoomNotAvailableException(roomNumber);
                room.Bookings.TryAdd(date, new Booking
                {
                    Guest = guest,
                    Date = date
                });
            }
        }
        public bool IsRoomAvailable(int roomNumber, DateTime date)
        {
            return _roomRepository.TryGetRoom(roomNumber, date, out var _);
        }
    }
}
