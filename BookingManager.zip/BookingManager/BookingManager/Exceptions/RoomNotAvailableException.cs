﻿using System;

namespace BookingManager.Exceptions
{
    [Serializable]
    internal class RoomNotAvailableException : Exception
    {
        public RoomNotAvailableException(int roomNumber) : base($"room {roomNumber} is not available")
        {
        }

        public RoomNotAvailableException(string message):base(message)
        {

        }
    }
}