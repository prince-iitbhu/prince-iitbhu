﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingManager.Domain
{
    class Booking
    {
        public string Guest { get; set; }

        public DateTime Date { get; set; }
    }
}
