﻿using System;
using System.Collections.Concurrent;

namespace BookingManager.Domain
{
    class Room
    {
        public int RoomNumber { get; set; }

        public ConcurrentDictionary<DateTime, Booking> Bookings { get; } = new ConcurrentDictionary<DateTime, Booking>();
    }
}
