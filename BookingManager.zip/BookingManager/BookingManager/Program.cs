﻿using BookingManager.Application;
using BookingManager.Exceptions;
using BookingManager.Interface;
using System;

namespace BookingManager
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IBookingManager bm = new BookingService();// create your manager here; 
                var today = new DateTime(2012, 3, 28);
                Console.WriteLine(bm.IsRoomAvailable(101, today)); // outputs true 
                bm.AddBooking("Patel", 101, today);
                Console.WriteLine(bm.IsRoomAvailable(101, today)); // outputs false 
                try
                {
                    bm.AddBooking("Li", 101, today); // throws an exception
                }
                catch (RoomNotAvailableException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                try
                {
                    bm.AddBooking("Li", 108, today); // throws an exception
                }
                catch(RoomNotAvailableException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                IBookingManagerV2 bookingManagerV2 = new BookingServiceV2();
                var availableRooms = bookingManagerV2.getAvailableRooms(today);
                Console.WriteLine(string.Concat(availableRooms));
                bookingManagerV2.AddBooking("Kumar", 102, today);
                Console.WriteLine(string.Concat(bookingManagerV2.getAvailableRooms(today)));
                Console.WriteLine(string.Concat(bookingManagerV2.getAvailableRooms(DateTime.Now)));
            }
            catch
            {
                Console.WriteLine("Unexpected Error");
            }
            Console.ReadKey();
        }
    }
}
