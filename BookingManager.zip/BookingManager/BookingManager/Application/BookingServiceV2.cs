﻿using BookingManager.Interface;
using BookingManager.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BookingManager.Application
{
    class BookingServiceV2 : BookingService, IBookingManagerV2
    {
        public IEnumerable<int> getAvailableRooms(DateTime date)
        {
            var rooms = RoomRepository.Instance.Rooms;
            return rooms.Where(r => !r.Value.Bookings.ContainsKey(date)).Select(r => r.Key);
        }
    }
}
